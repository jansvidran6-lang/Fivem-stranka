
const online = Math.random() > 0.3;
document.getElementById("status").innerText =
online ? "Server ONLINE 🟢" : "Server OFFLINE 🔴";

document.getElementById("wlForm").addEventListener("submit", e => {
  e.preventDefault();
  alert("Whitelist žádost odeslána!");
});
